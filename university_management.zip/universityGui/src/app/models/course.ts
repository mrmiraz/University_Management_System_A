export class Course{
    code!:String;
    name !:String;
    constructor(code:String, name:String){
        this.code = code;
        this.name = name;
    }

}