package com.miraz.universitybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversitybackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversitybackendApplication.class, args);
	}

}
