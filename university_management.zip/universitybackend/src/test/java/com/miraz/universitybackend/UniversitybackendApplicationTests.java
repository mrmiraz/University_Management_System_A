package com.miraz.universitybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversitybackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
